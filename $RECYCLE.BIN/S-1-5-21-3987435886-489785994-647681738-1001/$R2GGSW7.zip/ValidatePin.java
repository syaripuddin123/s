import java.util.Scanner;

public class ValidatePin {

    public static void main(String[] args) {
        
    }
}
