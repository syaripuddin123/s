import java.util.Scanner;

public class DisplayMultiples {

    public static void main(String args[]) {
       
    }

}
