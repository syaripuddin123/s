public class LoopShape {
    
    static void createRectangle(int width, int height){
        //Draw a Rectangle
        
        
    }
    
    static void createTriangle(int leg){
        //Draw an Isosceles Right Triangle
        
        
    }
}
