import java.util.Scanner;

public class ColorRange {

    public static void main(String args[]) {
        
        }
    }
