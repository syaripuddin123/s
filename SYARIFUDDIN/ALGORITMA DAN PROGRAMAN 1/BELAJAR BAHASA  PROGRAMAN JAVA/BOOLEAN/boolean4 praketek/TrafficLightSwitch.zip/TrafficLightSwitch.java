public class TrafficLightSwitch {

    public static void main(String args[]) {

       
    }

}
