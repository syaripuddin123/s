public class TrafficLightChecker {

    public static void main(String args[]) {
      
    }

}
